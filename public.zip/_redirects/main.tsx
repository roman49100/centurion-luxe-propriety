# Redirects pour React Router sur Cloudflare Pages
/*    /index.html   200
